import java.util.Scanner;
import java.util.HashMap;

public class MyGrades {
    
    // HashMap to store Student ID and corresponding name
    private static HashMap<String, String> studentInfo = new HashMap<>();
    
    // HashMap to store Student ID and corresponding grades
    private static HashMap<String, double[]> studentGrades = new HashMap<>();

    public static void main(String[] args) {
        // Initialize student data
        initializeStudentData();
        
        // Scanner for user input
        Scanner scanner = new Scanner(System.in);
        
        // Number of attempts
        int attempts = 0;
        boolean accountDeactivated = false;
        
        String studentId = "";
        
        // Loop to give the user 4 tries
        while (attempts < 3) {
            // Get Student ID
            System.out.println("Enter Student ID:");
            studentId = scanner.nextLine();
            
            // Verify if student ID exists
            if (studentInfo.containsKey(studentId)) {
                // Get student name and display welcome message
                String studentName = studentInfo.get(studentId);
                System.out.println("Alright " + studentName + ", here is your transcript:");
                
                // Get student grades and calculate GPA
                displayTranscript(studentId);
                
                // Ask for current GPA
                System.out.println("Enter your current GPA:");
                double currentGpa = scanner.nextDouble();
                
                // Assume user has completed 13 additional credits
                System.out.println("For 13 more credits, let's calculate your future GPA:");
                double futureGpa = calculateFutureGpa(currentGpa, 13);
                
                System.out.println("Your predicted GPA after 13 additional credits is: " + futureGpa);
                System.out.println("Stay focused! ✨");
                
                break; // Exit the loop if valid ID is entered
                
            } else {
                // Increment attempts
                attempts++;
                
                // If 4 wrong attempts, deactivate account
                if (attempts == 3) {
                    accountDeactivated = true;
                    System.out.println("❌ Account deactivated! 😵 You have entered the wrong ID 4 times. Student account permanently blocked.");
                } else {
                    System.out.println("Invalid Student ID. You have " + (4 - attempts) + " attempts left.");
                }
            }
        }
        
        // Close scanner
        scanner.close();
        
        if (accountDeactivated) {
            System.out.println("🚫 The user has passed away metaphorically. 😇 Rest in peace, dear account. 🕊️");
        }
    }
    
    // Method to initialize student data
    private static void initializeStudentData() {
        // Add student IDs and names
        studentInfo.put("887369111", "Roshaan Ameer");
        studentInfo.put("889369111", "Hamza Tiwana");
        
        // Add grades for each student: {ITSC 1213, MAT 2164, ITSC 2175, ITSC 4353}
        studentGrades.put("887369111", new double[] {92, 89, 94, 97});
        studentGrades.put("889369111", new double[] {85, 88, 90, 92});
    }
    
    // Method to display transcript
    private static void displayTranscript(String studentId) {
        double[] grades = studentGrades.get(studentId);
        System.out.println("Course ITSC 1213: " + grades[0] + "%");
        System.out.println("Course MAT 2164: " + grades[1] + "%");
        System.out.println("Course ITSC 2175: " + grades[2] + "%");
        System.out.println("Course ITSC 4353: " + grades[3] + "%");
    }
    
    // Method to calculate future GPA
    private static double calculateFutureGpa(double currentGpa, int newCredits) {
        // Assuming 13 additional credits with a high GPA (e.g., 4.0)
        int totalCredits = 13 + newCredits;
        double predictedGpa = ((currentGpa * newCredits) + (4.0 * 13)) / totalCredits;
        return predictedGpa;
    }
}
